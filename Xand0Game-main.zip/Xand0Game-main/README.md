# Xand0Game 
We Created an X an 0 Game using JAVA that is Interactable
The Main Page where the game is being commenced 
![Main Page](https://github.com/user-attachments/assets/035a4be6-40a8-4326-baca-f0836f5fcb33)
This is the First Page of the X and O game where we ask the players to Input there names
![First Page](https://github.com/user-attachments/assets/88117d30-f20d-45fe-a4eb-3ee036b8bbd7)
The Winning Page
![Winning Page](https://github.com/user-attachments/assets/31d725d1-6ab1-49b0-a769-d018076fa00b)
